<template>
  <div>
    我是团购订单
  </div>
</template>

<script>
export default {
  name: "GroupOrder",
};
</script>

<style>
</style>